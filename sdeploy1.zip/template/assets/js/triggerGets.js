document.getElementById('dashboard').addEventListener('click', function() {
    window.location.href = '/dashboard';
});
document.getElementById('survey').addEventListener('click', function() {
    window.location.href = '/survey';
});
document.getElementById('report').addEventListener('click', function() {
    window.location.href = '/report';
});
document.getElementById('home').addEventListener('click', function() {
    window.location.href = '/';
});
document.getElementById('login').addEventListener('click', function() {
    window.location.href = '/login';
});
document.getElementById('register').addEventListener('click', function() {
    window.location.href = 'register';
});

document.getElementById('logout').addEventListener('click', function() {
    window.location.href = '/logout';
});